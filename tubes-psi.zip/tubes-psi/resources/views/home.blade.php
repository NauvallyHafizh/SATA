@extends('layouts.main')

@section('container')
    <h2>Hi</h2>
@endsection